<section class="stories-section py-md-50px py-30px">
    <div class="container">
        <h1 class="pb-md-5 pb-4">Stories</h1>
        <div class="slider-container-for-side-disabled-buttons">
            <div class="swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                    <div class="swiper-slide">
                        <img src="/home/Image.png" style="border-radius: 50%"
                        class="card d-flex align-items-center mt-4-img-top" alt="...">
                    </div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </div>
</section>

