<section class="available-items-section">
    <h2 class="mt-5 mb-4 fw-normal">Available Items</h2>
    <div class="slider-container-for-side-buttons ">
        <div class="swiper slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="home/available-items/pizza.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Pizza</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/biryani.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Biryani</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/burger.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Burger</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/ice-cream.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Ice Cream</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/chemin.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Chewmin</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/shake.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Shake</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/steak.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Steak</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/pizza.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Pizza</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/biryani.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Chewmin</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/burger.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Burger</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/ice-cream.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Ice Cream</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/chemin.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Chewmin</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/shake.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Shake</h5>
                </div>
                <div class="swiper-slide">
                    <img src="home/available-items/steak.png" alt="">
                    <h5 class="mt-2 text-center fw-normal">Steak</h5>
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>