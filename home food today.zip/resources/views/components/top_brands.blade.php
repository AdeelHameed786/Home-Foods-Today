<section class="top-brands-section">
    <h2 class="mt-5 mb-4 fw-normal">Top Brands</h2>
    <div class="slider-container-for-side-buttons ">
        <div class="swiper slider">
            <div class="swiper-wrapper">      
                <div class="swiper-slide brand">
                    <img src="home/top-brands/kfc.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/mcdonald.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/subway.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/kfc.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/mcdonald.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/subway.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/kfc.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/mcdonald.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/subway.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/kfc.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/mcdonald.png" alt="">
                </div>
                <div class="swiper-slide brand">
                    <img src="home/top-brands/subway.png" alt="">
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>