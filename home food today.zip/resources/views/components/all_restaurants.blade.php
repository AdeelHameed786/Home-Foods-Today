<section class="all-restaurants-section mb-4">
    <h2 class="mt-5 mb-4 fw-normal">All Restaurants</h2>
    <div class="row">
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
        <div class="col-lg-4 mb-4 col-sm-6">
            <div class="card card-2 card-popular ">
                <div class="image-container">
                    <img src="/home/deals-and-discounts/1.jpeg" class="main-image" alt="...">
                    <div class="discount">
                        <div class="percentage">15</div>
                        <div class="percentage-sign-and-off-text-container">
                            <div class="percentage-sign">%</div>
                            <div class="off-text">Off</div>
                        </div>
                    </div>
                </div>
                <div class="content">
                    <h3 class="" style="font-size: 22px">Deal 1</h3>
                    <div class="d-flex">
                        
                        
                    </div>
                    <h3 style="font-size: 22px">$3.88</h3>
                </div>    
            </div>
        </div>
    </div>    
    <div class="row justify-content-center">
        <button class="btn btn-primary">
            View More
        </button>
    </div> 
</section>