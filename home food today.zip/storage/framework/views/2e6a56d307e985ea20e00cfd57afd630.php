<section class="discounted-items-section py-md-50px py-30px">
    <div class="container">
        <h1 class="pb-md-5 pb-4">Discounted Items</h1>
        <div class="row">
            <div class="col-xl-3 col-lg-4 col-sm-6 d-flex justify-content-center mb-xl-0 mb-md-3 mb-0">
                <div class="card-1 mb-md-0 mb-4 pb-xl-0 pb-3">
                    <img src="/home/FoodPhoto1.png" class="card-img-top" alt="...">
                    <h4 class="title">Greys Vage</h4>
                    <h4 class="days-remaining">6 Days Remaining</h4>
                    
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 d-flex justify-content-center mb-xl-0 mb-md-3 mb-0">
                <div class="card-1 mb-md-0 mb-4 pb-md-0 pb-xl-0 pb-3">
                    <img src="/home/FoodPhoto2.png" class="card-img-top" alt="...">
                    <h4 class="title">Greys Vage</h4>
                    <h4 class="days-remaining">6 Days Remaining</h4> 
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 d-flex justify-content-center mb-xl-0 mb-md-3 mb-0">
                <div class="card-1 mb-md-0 mb-4 pb-md-0 pb-xl-0 pb-3">
                    <img src="/home/FoodPhoto3.png" class="card-img-top" alt="...">
                    <h4 class="title">Greys Vage</h4>
                    <h4 class="days-remaining">6 Days Remaining</h4>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-6 d-flex justify-content-center mb-xl-0 mb-md-3 mb-0">
                <div class="card-1 mb-md-0 mb-4 pb-md-0 pb-xl-0 pb-3">
                    <img src="/home/FoodPhoto4.png" class="card-img-top" alt="...">
                    <h4 class="title">Greys Vage</h4>
                    <h4 class="days-remaining">6 Days Remaining</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH F:\xampp\htdocs\home foods today\resources\views/components/discounted.blade.php ENDPATH**/ ?>