<h1 class="p-5" style="font-size: 43px; text-align:center">Featured Restaurants</h1>
<div class="row">
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="popular1.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="foodWorldLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Foodworld</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">4.6</span> (45)</p>
                    </div>
                </div>
            </div>
            <h4 class="days mt-4">Opens tommorow</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="pizzaHub.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="pizzaHubLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Pizzahub</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">40</span></p>
                    </div>
                </div>
            </div>
            <h4 class="days mt-4">Opens tommorow</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="donutsHut.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="donutsHutLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Donuts Hut</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">20</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens Now</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="subway.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="subwayLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Donuts Hut</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">50</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens now</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="ruby.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="rubyLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Rubby Tuesday</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">26</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens now</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="kfc.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="kfcLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Kuakata Fried Chicken</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">53</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens now</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="redSquare.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="redSquareLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Red Square</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">50</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens now</h4>
          </div>
    </div>
    <div class="mt-5 col-xl-3 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
            <img src="taco.png" class="card-img-top" alt="...">
            <div class="d-flex mt-4">
                <img src="tacoLogo.png" width="65px" height="65px" alt="">
                <div class="ms-3">
                    <h3 style="font-size: 20px">Taco Belt</h3>
                    <div class="d-flex">
                        <img class="" src="star.png" width="30px" height="30px" alt="">
                        <p style="font-size: 20px" class=" ms-1"><span style="color: #913737">50</span></p>
                    </div>
                </div>
            </div>
            <h4 class="open mt-4">Opens now</h4>
          </div>
    </div>
</div><?php /**PATH D:\Xampp\htdocs\HomeFoods\resources\views/popularItems.blade.php ENDPATH**/ ?>