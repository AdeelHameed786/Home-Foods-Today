<main class="container pt-5">
    <h1>Stories</h1>
    <div class="slider-container" id="new-stories">
        <div class="row">
            <div class="col-xl-1 mob-story-button d-flex align-items-center justify-content-start">
                <div class="slider-arrows">
                    <button type="button" class="btn slider-arrow-prev"><img src="/home/Arrowleft.png" width="50px"
                            height="50px" alt=""></button>
                </div>
            </div>
            <div class="col-xl-10 mob-story col-md-8">
                <div class="slides-wrapper">
                    <div class="slides-container">
                        <ul class="slider-list">
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                            <li class="slider-item d-flex justify-content-center">
                                <div class="card d-flex align-items-center cardImg mt-4" style="width: 14rem;">
                                    <img src="/home/Image.png" style="border-radius: 50%"
                                        class="card d-flex align-items-center mt-4-img-top" alt="...">

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-1 mob-story-button d-flex align-items-center justify-content-end">
                <div class="slider-arrows">
                    <button type="button" class="btn slider-arrow-next"><img src="/home/Arrowright.png" width="50px"
                            height="50px" alt=""></button>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function adjustColumnWidths() {
        // Check if the viewport width is less than or equal to the mobile breakpoint
        if (window.innerWidth <= 1000) {
            const col1s = document.querySelectorAll('.mob-story-button');
            const col10 = document.querySelector('.mob-story');

            // Set widths for both .col-xl-1 divs (assuming two exist)
            for (const col1 of col1s) {
                col1.style.width = '20%';
            }

            // Set width for the .col-xl-10 div
            col10.style.width = '60%';
        } else {
            // Reset widths to their original Bootstrap classes for desktop
            const allCols = document.querySelectorAll('.mob-story-button, .mob-story');
            for (const col of allCols) {
                col.style.width = null; // Remove inline width styles
            }
        }
    }

    // Call the function on page load and resize
    window.addEventListener('load', adjustColumnWidths);
    window.addEventListener('resize', adjustColumnWidths);


    (function() {
        'use strict';

        // A class for building sliders from it
        class Slider {
            constructor(id, mediaQueries) {
                // Get HTML elements
                this.slider = document.querySelector(`#${id}`);
                this.sliderList = this.slider.querySelector('.slider-list');
                this.sliderItems = this.slider.querySelectorAll('.slider-item');
                this.sliderNext = this.slider.querySelector('.slider-arrow-next');
                this.sliderPrev = this.slider.querySelector('.slider-arrow-prev');

                // Get media queries
                this.mediaQueryList = [window.matchMedia(`screen and (max-width:${mediaQueries[0] - 1}px)`)];
                mediaQueries.forEach((mediaQuery) => {
                    this.mediaQueryList.push(window.matchMedia(
                        `screen and (min-width:${mediaQuery}px)`));
                });

                // Define global variables
                this.numberOfVisibleItems = null;
                this.currentItemIndex = null;
                this.sliderItemsLength = this.sliderItems.length;
                this.mediaQueryLength = this.mediaQueryList.length;

                // Add event listener: to call the run function again when screen resized
                this.mediaQueryList.forEach((mediaQuery) => {
                    mediaQuery.addEventListener('change', () => {
                        this.run();
                    });
                });

                // Add event listener: to go to next slide
                this.sliderNext.addEventListener('click', () => {
                    if (this.currentItemIndex < this.sliderItemsLength - this.numberOfVisibleItems) {
                        this.currentItemIndex++;
                        this.shiftSlides();
                    }
                });

                // Add event listener: to go to previous slide
                this.sliderPrev.addEventListener('click', () => {
                    if (this.currentItemIndex > 0) {
                        this.currentItemIndex--;
                        this.shiftSlides();
                    }
                });

                // Disable focus on all slides links
                this.sliderItems.forEach((item) => {
                    const elements = item.querySelectorAll('a');
                    elements.forEach((element) => {
                        element.tabIndex = '-1';
                    });
                });

                // Add event listener: to scroll down to slider when previous arrow focused
                this.sliderPrev.addEventListener('focusin', () => {
                    this.slider.scrollIntoView();
                });

                // Add event listener: to scroll down to slider when next arrow focused
                this.sliderNext.addEventListener('focusin', () => {
                    this.slider.scrollIntoView();
                });
            }

            // Run the slider
            run() {
                let index = this.mediaQueryLength - 1;
                while (index >= 0) {
                    if (this.mediaQueryList[index].matches) {
                        // Set number of visible slides
                        this.numberOfVisibleItems = index + 1;

                        // Reset the slider
                        this.currentItemIndex = 0;

                        // Adjust slider list styles for mobile version
                        if (index === 0) {
                            // For mobile
                            this.sliderList.style.transform = 'translateY(0%)';
                            this.sliderList.style.width = 'calc(600% + 96px)';
                        } else {
                            // For other screen sizes
                            this.sliderList.style.transform = 'translateX(0%)';
                            this.sliderList.style.width =
                                `calc(${(70 / this.numberOfVisibleItems) * this.sliderItemsLength}% + ${(this.sliderItemsLength / this.numberOfVisibleItems) * 16}px)`;
                        }

                        // Set slides width
                        this.sliderItems.forEach((item) => {
                            item.style.width = `${100 / this.numberOfVisibleItems}%`;
                        });

                        // Adjust number of visible items
                        this.sliderItems.forEach((item, itemIndex) => {
                            if (itemIndex < this.numberOfVisibleItems) {
                                item.style.display = 'block';
                            } else {
                                item.style.display = 'none';
                            }
                        });

                        // Exit the loop
                        break;
                    }
                    index--;
                }
            }

            // A function to shift slides left and right
            shiftSlides() {
                this.sliderList.style.transform =
                    `translateX(-${(100 / this.sliderItemsLength) * this.currentItemIndex}%)`;

                // Update arrow opacity based on current slide position
                if (this.currentItemIndex === 0) {
                    // First image reached
                    this.sliderPrev.style.opacity = '0.5';
                } else if (this.currentItemIndex === this.sliderItemsLength - this.numberOfVisibleItems) {
                    // Last image reached
                    this.sliderNext.style.opacity = '0.5';
                } else {
                    // Neither first nor last image
                    this.sliderPrev.style.opacity = '1';
                    this.sliderNext.style.opacity = '1';
                }
            }
        }

        /* 
        Note about creating new slider:
        First parameter is the id of the HTML slider-container element of each slider.
        Second parameter is an array of the media queries (breaking points) where the number of slides increases.
        */

        // Create a new slider and run it
        new Slider('new-stories', [576, 992]).run();

        // Create a new slider and run it
        // new Slider('featured-products', [576, 768, 992]).run();
    })();
</script>


</html>
<?php /**PATH F:\xampp\htdocs\home foods today latest 4\resources\views/components/stories.blade.php ENDPATH**/ ?>