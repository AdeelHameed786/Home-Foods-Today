<style>
    .cardImgFood img {
        width: 190px !important;
    }

    .app {
        background-image: url('AppDownload1.png');
        /* Replace 'background-image.jpg' with the path to your desired background image */
        background-size: cover;
        /* This ensures that the background image covers the entire area of the row */
        background-position: center;
        /* Centers the background image */
        background-repeat: no-repeat;
        /* Prevents the background image from repeating */
        height: 300px;
        /* Set a specific height for the row */
        display: flex;
        /* Use flexbox to align items */
        justify-content: center;
        /* Center items horizontally */
        align-items: center;
        /* Center items vertically */
    }

    .app img {
        max-width: 100%;
        /* Ensure the image doesn't exceed the width of its container */
        height: auto;
        /* Maintain aspect ratio */
    }
</style>
<div class="container-fluid mt-5">
    <div class="container pt-5 pb-5">
        <h2 style="font-size: 43px">Search by Food</h2>
        <div class="slider-container" id="searchByFood">
            <div class="row">
                <div class="slider-arrows  d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary">View All <img src="viewAll.png"
                            alt=""></button>
                    <button type="button" class="btn slider-arrow-prev"><img src="Arrowleft.png" width="50px"
                            height="50px" alt=""></button>
                    <button type="button" class="btn slider-arrow-next"><img src="Arrowright.png" width="50px"
                            height="50px" alt=""></button>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="slides-wrapper">
                        <div class="slides-container">
                            <ul class="slider-list">
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (1).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Steak</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (3).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Chowmein</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (4).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Sub-sandiwch
                                        </h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (5).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Noodles</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (6).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Burger</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (7).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Pizza</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (3).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Chowmein</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (4).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Sub-sandiwch
                                        </h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="searchbyfood (5).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Noodles</h1>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="container p-5" style="background-color: #FEEFD0">
        <div class="row p-5" style="background-color: white; margin: 40px 100px; border-radius: 46px">
            <div class="col-xl-4">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5">
                            <img src="discount.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Daily
                                    Discounts</b></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5">
                            <img src="tracking.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Live
                                    Tracking</b></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 d-flex">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5">
                            <img src="trackingd.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Quick
                                    Delivery</b></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container" style="background-color: #FEEFD0">
        <div class="row">
            <img src="AppDownload.png" alt="">
        </div>
        
    </div>
    
</div>
<script>
    (function() {
        'use strict';

        // A class for building sliders from it
        class Slider {
            constructor(id, mediaQueries) {
                // Get HTML elements
                this.slider = document.querySelector(`#${id}`);
                this.sliderList = this.slider.querySelector('.slider-list');
                this.sliderItems = this.slider.querySelectorAll('.slider-item');
                this.sliderNext = this.slider.querySelector('.slider-arrow-next');
                this.sliderPrev = this.slider.querySelector('.slider-arrow-prev');

                // Get media queries
                this.mediaQueryList = [window.matchMedia(`screen and (max-width:${mediaQueries[0] - 1}px)`)];
                mediaQueries.forEach((mediaQuery) => {
                    this.mediaQueryList.push(window.matchMedia(
                        `screen and (min-width:${mediaQuery}px)`));
                });

                // Define global variables
                this.numberOfVisibleItems = null;
                this.currentItemIndex = null;
                this.sliderItemsLength = this.sliderItems.length;
                this.mediaQueryLength = this.mediaQueryList.length;

                // Add event listener: to call the run function again when screen resized
                this.mediaQueryList.forEach((mediaQuery) => {
                    mediaQuery.addEventListener('change', () => {
                        this.run();
                    });
                });

                // Add event listener: to go to next slide
                this.sliderNext.addEventListener('click', () => {
                    if (this.currentItemIndex < this.sliderItemsLength - this.numberOfVisibleItems) {
                        this.currentItemIndex++;
                        this.shiftSlides();
                    }
                });

                // Add event listener: to go to previous slide
                this.sliderPrev.addEventListener('click', () => {
                    if (this.currentItemIndex > 0) {
                        this.currentItemIndex--;
                        this.shiftSlides();
                    }
                });

                // Disable focus on all slides links
                this.sliderItems.forEach((item) => {
                    const elements = item.querySelectorAll('a');
                    elements.forEach((element) => {
                        element.tabIndex = '-1';
                    });
                });

                // Add event listener: to scroll down to slider when previous arrow focused
                this.sliderPrev.addEventListener('focusin', () => {
                    this.slider.scrollIntoView();
                });

                // Add event listener: to scroll down to slider when next arrow focused
                this.sliderNext.addEventListener('focusin', () => {
                    this.slider.scrollIntoView();
                });
            }

            // Run the slider
            run() {
                let index = this.mediaQueryLength - 1;
                while (index >= 0) {
                    if (this.mediaQueryList[index].matches) {
                        // Set number of visible slides
                        this.numberOfVisibleItems = index + 1;

                        // Reset the slider
                        this.currentItemIndex = 0;
                        this.sliderList.style.transform = 'translateX(0%)';

                        // Set slider list width
                        this.sliderList.style.width =
                            `calc(${(50 / this.numberOfVisibleItems) * this.sliderItemsLength}% + ${(this.sliderItemsLength / this.numberOfVisibleItems) * 16}px)`;

                        // Set slides width
                        this.sliderItems.forEach((item) => {
                            item.style.width = `${100 / this.numberOfVisibleItems}%`;
                        });

                        // Exit the loop
                        break;
                    }
                    index--;
                }
            }

            // A function to shift slides left and right
            shiftSlides() {
                this.sliderList.style.transform =
                    `translateX(-${(100 / this.sliderItemsLength) * this.currentItemIndex}%)`;
            }
        }

        /* 
        Note about creating new slider:
        First parameter is the id of the HTML slider-container element of each slider.
        Second parameter is an array of the media queries (breaking points) where the number of slides increases.
        */

        // Create a new slider and run it
        new Slider('searchByFood', [576, 992]).run();

        // Create a new slider and run it
        new Slider('featured-products', [576, 768, 992]).run();
    })();
</script>
<?php /**PATH D:\Xampp\htdocs\HomeFoods\resources\views/searchByFood.blade.php ENDPATH**/ ?>