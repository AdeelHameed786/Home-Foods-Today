<div class="container-fluid">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="SliderCarosal.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="SliderCarosal.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="SliderCarosal.png" class="d-block w-100" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>
<?php echo $__env->make('stories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-4">
    <h1 class="p-5" style="font-size: 43px; text-align:center">Discounted items</h1>
    <div class="row">
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="FoodPhoto1.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h4 >Greys Vage</h4>
                  <h4 class="days">6 Days Remaining</h4>
                </div>
              </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="FoodPhoto2.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h4 >Greys Vage</h4>
                  <h4 class="days">6 Days Remaining</h4>
                </div>
              </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="FoodPhoto3.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h4 >Greys Vage</h4>
                  <h4 class="days">6 Days Remaining</h4>
                </div>
              </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="FoodPhoto4.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h4 >Greys Vage</h4>
                  <h4 class="days">6 Days Remaining</h4>
                </div>
              </div>
        </div>
    </div>
</div>
<div class="container-fluid work pb-5 mt-5">
    <h1 class="p-5" style="font-size: 43px; text-align:center">How does it work</h1>
    <div class="container">
        <div class="row">
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card" style="width: 18rem; background-color:transparent">
                    <img src="Frame 730.png" class="card-img-top" alt="...">
                  </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card" style="width: 18rem; background-color:transparent">
                    <img src="Frame 731.png" class="card-img-top" alt="...">
                  </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card" style="width: 18rem; background-color:transparent">
                    <img src="Frame 732.png" class="card-img-top" alt="...">
                  </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card" style="width: 18rem; background-color:transparent">
                    <img src="Frame 733.png" class="card-img-top" alt="...">
                  </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container pb-5">
    <?php echo $__env->make('popularItems', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('searchByFood', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('masterChef', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\HomeFoods\resources\views/homeContent.blade.php ENDPATH**/ ?>