<style>
    .footer-link li{
        cursor: pointer;
    }

    .footer-link li:hover{
        color: #913737;
    }

    @media (max-width: 1000px) {

    .footer-container {
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
    }
</style>
<div class="container-fluid" style="background-color: #212121">
    <div class="container footer-container" style="padding: 20px 100px">
        <div class="row">
            <hr style="border-bottom: 2px solid white; padding: 15px;">
            <div class="col-xl-2 footer">
                <h4>Company</h4>
                <ul class="footer-link">
                    <li>About us</li>
                    <li>Team</li>
                    <li>Careers</li>
                    <li>Blog</li>
                </ul>
            </div>
            <div class="col-xl-2 footer">
                <h4>Contact</h4>
                <ul class="footer-link">
                    <li>Help & Support</li>
                    <li>Partner with us</li>
                    <li>Ride with us</li>
                </ul>
            </div>
            <div class="col-xl-3 footer">
                <h4>Legal</h4>
                <ul class="footer-link">
                    <li>Terms & Conditions</li>
                    <li>Refund & Cancellation</li>
                    <li>Privacy Policy</li>
                    <li>Cookie Policy</li>
                </ul>
            </div>
            <div class="col-xl-5 follow">
                <h4>Follow Us</h4>
                <div class="d-flex social">
                    <a href="#"><img src="/home/instagram.png" alt=""></a>
                    <a href="#"><img src="/home/facebook.png" alt=""></a>
                    <a href="#"><img src="/home/twitter.png" alt=""></a>
                </div>
                <h4>Receive exclusive offers in your mailbox</h4>
                <form class="d-flex" style="padding: 0px 30px" role="search">
                    <div class="input-container">
                        <img class="search" src="/home/envelope.png" alt="">
                        <input class="form-control search-form me-2" type="email" placeholder="Enter Your email"
                            aria-label="Search">
                    </div>
                    <button class="btn btn-primary ms-2" type="submit">Subscribe</button>
                </form>
            </div>
            <hr style="border-bottom: 2px solid white; padding: 15px;">
            <div class="copyright">
                <h4>All rights Reserved © Your Company, 2021</h4>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\home foods today\resources\views/footer.blade.php ENDPATH**/ ?>