<style>
    @media (max-width: 1000px) {
        .custom-card-food {
            padding: 2rem !important;
        }

        .center-col-5 {
            display: flex;
            justify-content: center;
        }

        .center-col-7 h2 {
            text-align: center !important;
        }
    }
</style>
<div class="container-fluid mt-5" style="background-color: #FEFAF1">
    <div class="container pt-5 pb-5">
        <h2 style="font-size: 43px">Search by Food</h2>
        <div class="slider-container" id="searchByFood">
            <div class="row">
                <div class="slider-arrows  d-flex justify-content-end">
                    <button type="button" class="btn">View All <img src="/home/viewAll.png" alt=""></button>
                    <button type="button" class="btn slider-arrow-prev"><img src="/home/Arrowleft.png" width="50px"
                            height="50px" alt=""></button>
                    <button type="button" class="btn slider-arrow-next"><img src="/home/Arrowright.png" width="50px"
                            height="50px" alt=""></button>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="slides-wrapper">
                        <div class="slides-container">
                            <ul class="slider-list">
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (1).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Steak</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (3).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Chowmein</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (4).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Sub-sandiwch
                                        </h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (5).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Noodles</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (6).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Burger</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (7).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Pizza</h1>

                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (3).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Chowmein</h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (4).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Sub-sandiwch
                                        </h1>
                                    </div>
                                </li>
                                <li class="slider-item d-flex justify-content-center">
                                    <div class="card cardImgFood mt-4"
                                        style="width: 13rem; background-color: transparent !important;">
                                        <img src="/home/searchbyfood (5).png" style="border-radius: 50%"
                                            class="card mt-4-img-top" alt="...">
                                        <h1 style="font-size: 22px; padding: 10px 27px 0px 0px;">Noodles</h1>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" style="background-color: #FEEFD0">
    <div class="container custom-card-food p-5">
        <div class="row p-5" style="background-color: white; border-radius: 46px">
            <div class="col-xl-4">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5 center-col-5">
                            <img src="/home/discount.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7 center-col-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Daily
                                    Discounts</b></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5 center-col-5">
                            <img src="/home/tracking.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7 center-col-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Live
                                    Tracking</b></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 d-flex">
                <div class="card">
                    <div class="row">
                        <div class="col-xl-5 center-col-5">
                            <img src="/home/trackingd.png" width="110px" alt="">
                        </div>
                        <div class="col-xl-7 center-col-7">
                            <h2 style="font-size: 30px; color: #913737; padding: 25px 0px 0px 0px;"><b>Quick
                                    Delivery</b></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <img src="/home/AppDownload.png" alt="">
        </div>
        
    </div>
</div>
<script>
    (function() {
        'use strict';

        // A class for building sliders from it
        class Slider {
            constructor(id, mediaQueries) {
                // Get HTML elements
                this.slider = document.querySelector(`#${id}`);
                this.sliderList = this.slider.querySelector('.slider-list');
                this.sliderItems = this.slider.querySelectorAll('.slider-item');
                this.sliderNext = this.slider.querySelector('.slider-arrow-next');
                this.sliderPrev = this.slider.querySelector('.slider-arrow-prev');

                // Get media queries
                this.mediaQueryList = [window.matchMedia(`screen and (max-width:${mediaQueries[0] - 1}px)`)];
                mediaQueries.forEach((mediaQuery) => {
                    this.mediaQueryList.push(window.matchMedia(
                        `screen and (min-width:${mediaQuery}px)`));
                });

                // Define global variables
                this.numberOfVisibleItems = null;
                this.currentItemIndex = null;
                this.sliderItemsLength = this.sliderItems.length;
                this.mediaQueryLength = this.mediaQueryList.length;

                // Add event listener: to call the run function again when screen resized
                this.mediaQueryList.forEach((mediaQuery) => {
                    mediaQuery.addEventListener('change', () => {
                        this.run();
                    });
                });

                // Add event listeners for the buttons
                this.sliderNext.addEventListener('click', () => {
                    if (!this.sliderNext.disabled) {
                        this.currentItemIndex++;
                        this.shiftSlides();
                        this.toggleArrows();
                    }
                });

                this.sliderPrev.addEventListener('click', () => {
                    if (!this.sliderPrev.disabled) {
                        this.currentItemIndex--;
                        this.shiftSlides();
                        this.toggleArrows();
                    }
                });

                // Run the slider initially
                this.run();
            }

            // Run the slider
            run() {
                let index = this.mediaQueryLength - 1;
                while (index >= 0) {
                    if (this.mediaQueryList[index].matches) {
                        // Set number of visible slides
                        this.numberOfVisibleItems = index + 1;

                        // Reset the slider
                        this.currentItemIndex = 0;
                        this.sliderList.style.transform = 'translateX(0%)';

                        // Set slider list width
                        this.sliderList.style.width =
                            `calc(${(50 / this.numberOfVisibleItems) * this.sliderItemsLength}% + ${(this.sliderItemsLength / this.numberOfVisibleItems) * 16}px)`;

                        // Set slides width
                        this.sliderItems.forEach((item) => {
                            item.style.width = `${100 / this.numberOfVisibleItems}%`;
                        });

                        // Toggle arrows initially
                        this.toggleArrows();

                        // Exit the loop
                        break;
                    }
                    index--;
                }
            }

            // A function to toggle arrows based on slider position
            toggleArrows() {
                // Disable previous button if at the start
                this.sliderPrev.disabled = this.currentItemIndex === 0;
                this.sliderPrev.style.opacity = this.currentItemIndex === 0 ? '0.5' : '1';
                this.sliderPrev.style.border = this.currentItemIndex === 0 ? 'none' :
                'none'; // Set border

                // Disable next button if at the end
                this.sliderNext.disabled = this.currentItemIndex >= this.sliderItemsLength - this
                    .numberOfVisibleItems;
                this.sliderNext.style.opacity = this.currentItemIndex >= this.sliderItemsLength - this
                    .numberOfVisibleItems ? '0.5' : '1';
                this.sliderNext.style.border = this.currentItemIndex >= this.sliderItemsLength - this
                    .numberOfVisibleItems ? 'none' : 'none'; // Set border
            }


            // A function to shift slides left and right
            shiftSlides() {
                this.sliderList.style.transform =
                    `translateX(-${(100 / this.sliderItemsLength) * this.currentItemIndex}%)`;
            }
        }

        // Create a new slider and run it
        new Slider('searchByFood', [576, 992]);

        // Create a new slider and run it
        new Slider('featured-products', [576, 768, 992]);
    })();
</script>
<?php /**PATH F:\xampp\htdocs\home foods today latest 4\resources\views/components/searchByFood.blade.php ENDPATH**/ ?>