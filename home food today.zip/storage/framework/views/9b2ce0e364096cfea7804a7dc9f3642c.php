<div class="container-fluid work pb-5 mt-5">
    <h1 class="p-5" style="font-size: 43px; text-align:center">How does it work</h1>
    <div class="container ps-5 pe-5">
        <div class="row">
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card align-items-center" style="width: 18rem; background-color:transparent">
                    <img src="/home/howdoesitwork (4).png" class="card-img-top" alt="..." style="width: 86px !important">
                    <h4 class="pt-4" style="font-size: 22px; color: #913737; font-weight: 700">Select location</h4>
                    <p style="font-size: 18px; text-align:center">Choose the location where your food will be delivered.</p>
                </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card align-items-center" style="width: 18rem; background-color:transparent">
                    <img src="/home/howdoesitwork (3).png" class="card-img-top" alt="..." style="width: 86px !important">
                    <h4 class="pt-4" style="font-size: 22px; color: #913737; font-weight: 700">Choose order</h4>
                    <p style="font-size: 18px; text-align:center">Check over hundreds of menus to pick your favorite food</p>
                </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card align-items-center" style="width: 18rem; background-color:transparent">
                    <img src="/home/howdoesitwork (2).png" class="card-img-top" alt="..." style="width: 71px !important">
                    <h4 class="pt-4" style="font-size: 22px; color: #913737; font-weight: 700">Pay advanced</h4>
                    <p style="font-size: 18px; text-align:center">It's quick, safe, and simple. Select several methods of payment</p>
                </div>
            </div>
            <div class="col-xl-3 mt-3 d-flex justify-content-center">
                <div class="card align-items-center" style="width: 18rem; background-color:transparent">
                    <img src="/home/howdoesitwork (1).png" class="card-img-top" alt="..." style="width: 115px !important">
                    <h4 class="pt-4" style="font-size: 22px; color: #913737; font-weight: 700">Enjoy meals</h4>
                    <p style="font-size: 18px; text-align:center">Food is made and delivered directly to your home.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\home foods today latest 4\resources\views/components/howDoesItWork.blade.php ENDPATH**/ ?>