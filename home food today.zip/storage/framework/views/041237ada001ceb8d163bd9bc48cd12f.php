<section class="daily-deals-section">
    <h2 class="mt-md-5 mt-4 mb-4 fw-normal">Your Daily Deals</h2>
    <div class="slider-container-for-side-buttons ">
        <div class="swiper slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="home/daily-deals/burger-1.png" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="home/daily-deals/burger-1.png" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="home/daily-deals/burger-1.png" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="home/daily-deals/burger-1.png" alt="">
                </div>
                <div class="swiper-slide">
                    <img src="home/daily-deals/burger-1.png" alt="">
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section><?php /**PATH F:\xampp\htdocs\home foods today\resources\views/components/daily_deals.blade.php ENDPATH**/ ?>