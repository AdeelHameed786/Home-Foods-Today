<div class="container pt-5">
    <h1 class="pb-5" style="font-size: 43px; text-align:center">Discounted items</h1>
    <div class="row">
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="/home/FoodPhoto1.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4>Greys Vage</h4>
                    <h4 class="days">6 Days Remaining</h4>
                </div>
            </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="/home/FoodPhoto2.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4>Greys Vage</h4>
                    <h4 class="days">6 Days Remaining</h4>
                </div>
            </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="/home/FoodPhoto3.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4>Greys Vage</h4>
                    <h4 class="days">6 Days Remaining</h4>
                </div>
            </div>
        </div>
        <div class="col-xl-3 d-flex justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="/home/FoodPhoto4.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h4>Greys Vage</h4>
                    <h4 class="days">6 Days Remaining</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\home foods today\resources\views/homepage/discounted.blade.php ENDPATH**/ ?>