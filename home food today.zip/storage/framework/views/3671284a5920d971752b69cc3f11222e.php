
<section class="specific-deals">
    <div class="container">
        <div class="card-4 my-5">
            <div class="row g-0">
                <div class="col-md-4 card-content-col">
                    <div class="card-content">
                        <div class="card-title-and-card-text mt-xl-5">
                            <h3 class="card-title">Best deals Crispy Sandwiches</h3>
                            <p class="card-desc">Enjoy the large size of sandwiches. Complete perfect slice of sandwiches.</p>
                        </div>
                        <a href="#" class="btn btn-primary view-details-link">View More Details <i id="right" class="fa-solid fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-md-8 main-image-col">
                    <img src="/home/detail1.png" class="img-fluid rounded-end main-image" alt="...">
                </div>
            </div>
        </div>
        <div class="card-4 my-5">
            <div class="row g-0">
                <div class="col-md-8 main-image-col">
                    <img src="/home/detail2.png" class="img-fluid rounded-start main-image" alt="...">
                </div>
                <div class="col-md-4 card-content-col">
                    <div class="card-content">
                        <div class="card-title-and-card-text mt-xl-5">
                            <h3 class="card-title">Best deals Crispy Sandwiches</h3>
                            <p class="card-desc">Enjoy the large size of sandwiches. Complete perfect slice of sandwiches.</p>
                        </div>
                        <a href="#" class="btn btn-primary view-details-link">View More Details <i id="right" class="fa-solid fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-4 my-5">
            <div class="row g-0">
                <div class="col-md-4 card-content-col">
                    <div class="card-content">
                        <div class="card-title-and-card-text mt-xl-5">
                            <h3 class="card-title">Best deals Crispy Sandwiches</h3>
                            <p class="card-desc">Enjoy the large size of sandwiches. Complete perfect slice of sandwiches.</p>
                        </div>
                        <a href="#" class="btn btn-primary view-details-link">View More Details <i id="right" class="fa-solid fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-md-8 main-image-col">
                    <img src="/home/detail3.png" class="img-fluid rounded-end main-image" alt="...">
                </div>
            </div>
        </div>
    </div>
    
</section>
<?php /**PATH F:\xampp\htdocs\home foods today\resources\views/components/details.blade.php ENDPATH**/ ?>