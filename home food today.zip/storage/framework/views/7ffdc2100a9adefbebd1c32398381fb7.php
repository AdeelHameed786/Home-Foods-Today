
    <section class="popular-items pt-80px pb-50px">
        <div class="container">
            <h1>Popular Items</h1>
            <div class="slider-container-for-side-disabled-buttons">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" alt="..." class="mt-4 img-top" >
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" class=" mt-4 img-top" alt="...">
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" class=" mt-4 img-top" alt="...">
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" class=" mt-4 img-top" alt="...">
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" class=" mt-4 img-top" alt="...">
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                        <div class="swiper-slide slider-item d-flex justify-content-center">
                            <div class="card-1 card-popular mt-md-5 mt-4">
                                <img src="/home/burger.png" class=" mt-4 img-top" alt="...">
                                <h3 class="mt-3" style="font-size: 22px">Cheese Burger</h3>
                                <div class="d-flex">
                                    <img class="mt-2" src="/home/pin.png" width="16px" height="20px">
                                    <p class="ms-2" style="font-size: 22px; color:#913737">Burger Arena
                                    </p>
                                </div>
                                <h3 style="font-size: 22px">$3.88</h3>
                                <a href="#" class="p-3 btn btn-primary w-100">Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </div>
    </section>
    

<?php /**PATH F:\xampp\htdocs\home food today\resources\views/components/popular_items.blade.php ENDPATH**/ ?>